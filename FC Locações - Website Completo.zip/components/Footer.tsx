import { Truck, Phone, Mail, MapPin, Clock, Facebook, Instagram, Linkedin } from 'lucide-react';
import { Button } from './ui/button';
import { Separator } from './ui/separator';

export function Footer() {
  const currentYear = new Date().getFullYear();

  const services = [
    'Locação de Caminhões Munck',
    'Locação de Cestos Aéreos',
    'Transporte com Caminhões 3/4',
    'Içamento de Cargas',
    'Serviços 24 Horas',
    'Operadores Qualificados'
  ];

  const areas = [
    'São Paulo Capital',
    'ABC Paulista',
    'Grande São Paulo',
    'Guarulhos',
    'Osasco',
    'Barueri'
  ];

  return (
    <footer className="bg-fc-dark-gray text-white">
      {/* Portal do Cliente CTA */}
      <div className="fc-orange py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="mb-4 md:mb-0">
              <h3 className="text-xl font-semibold text-white mb-2">
                Acesse o Portal do Cliente
              </h3>
              <p className="text-white/90">
                Gerencie suas cotações, acompanhe pedidos e envie veículos para consignação.
              </p>
            </div>
            <Button 
              size="lg"
              className="bg-white text-fc-dark-gray hover:bg-gray-100 px-8"
            >
              Acessar Portal
            </Button>
          </div>
        </div>
      </div>

      {/* Main Footer */}
      <div className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {/* Company Info */}
            <div>
              <div className="flex items-center space-x-2 mb-6">
                <div className="w-10 h-10 fc-orange rounded-lg flex items-center justify-center">
                  <Truck className="w-6 h-6 text-white" />
                </div>
                <div>
                  <div className="font-bold text-xl text-white">FC Locações</div>
                  <div className="text-xs text-gray-400">Caminhões Munck & Cestos Aéreos</div>
                </div>
              </div>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Há mais de 15 anos no mercado, oferecemos soluções completas em locação de equipamentos para içamento e transporte.
              </p>
              
              {/* Social Media */}
              <div className="flex space-x-4">
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-fc-orange p-2">
                  <Facebook className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-fc-orange p-2">
                  <Instagram className="w-5 h-5" />
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-400 hover:text-fc-orange p-2">
                  <Linkedin className="w-5 h-5" />
                </Button>
              </div>
            </div>

            {/* Services */}
            <div>
              <h4 className="font-semibold text-white mb-6">Nossos Serviços</h4>
              <ul className="space-y-3">
                {services.map((service, index) => (
                  <li key={index}>
                    <a 
                      href="#" 
                      className="text-gray-300 hover:text-fc-orange transition-colors duration-200"
                    >
                      {service}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Service Areas */}
            <div>
              <h4 className="font-semibold text-white mb-6">Áreas Atendidas</h4>
              <ul className="space-y-3">
                {areas.map((area, index) => (
                  <li key={index}>
                    <span className="text-gray-300">{area}</span>
                  </li>
                ))}
              </ul>
              <div className="mt-6">
                <a 
                  href="#" 
                  className="text-fc-orange hover:text-orange-400 transition-colors duration-200 text-sm font-medium"
                >
                  Ver todas as cidades →
                </a>
              </div>
            </div>

            {/* Contact Info */}
            <div>
              <h4 className="font-semibold text-white mb-6">Contato</h4>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Phone className="w-5 h-5 text-fc-orange mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">(11) 9999-9999</p>
                    <p className="text-gray-300 text-sm">WhatsApp disponível</p>
                  </div>
                </div>
                
                <div className="flex items-start space-x-3">
                  <Mail className="w-5 h-5 text-fc-orange mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">contato@fclocacoes.com.br</p>
                    <p className="text-gray-300 text-sm">Resposta em até 2h</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <MapPin className="w-5 h-5 text-fc-orange mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">São Paulo, SP</p>
                    <p className="text-gray-300 text-sm">Atendemos toda Grande SP</p>
                  </div>
                </div>

                <div className="flex items-start space-x-3">
                  <Clock className="w-5 h-5 text-fc-orange mt-0.5 flex-shrink-0" />
                  <div>
                    <p className="text-white font-medium">24 horas</p>
                    <p className="text-gray-300 text-sm">Todos os dias da semana</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Separator className="bg-gray-700" />

      {/* Bottom Footer */}
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <div className="text-gray-400 text-sm">
              © {currentYear} FC Locações. Todos os direitos reservados.
            </div>
            <div className="flex space-x-6 text-sm">
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                Política de Privacidade
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                Termos de Uso
              </a>
              <a href="#" className="text-gray-400 hover:text-white transition-colors duration-200">
                Certificações
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}