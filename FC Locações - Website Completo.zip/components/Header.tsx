import { useState } from 'react';
import { Button } from './ui/button';
import { Menu, X, Truck, Phone, Mail, MapPin } from 'lucide-react';

interface HeaderProps {
  currentPage?: string;
}

export function Header({ currentPage = 'home' }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const navigation = [
    { name: 'Início', href: '#home', key: 'home' },
    { name: 'Frota', href: '#frota', key: 'frota' },
    { name: 'Sobre', href: '#sobre', key: 'sobre' },
    { name: 'Contato', href: '#contato', key: 'contato' },
  ];

  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      {/* Top Bar */}
      <div className="fc-dark-gray text-white py-2">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center text-sm">
            <div className="flex items-center space-x-6">
              <div className="flex items-center space-x-1">
                <Phone className="w-3 h-3" />
                <span>(11) 9999-9999</span>
              </div>
              <div className="flex items-center space-x-1">
                <Mail className="w-3 h-3" />
                <span>contato@fclocacoes.com.br</span>
              </div>
              <div className="hidden md:flex items-center space-x-1">
                <MapPin className="w-3 h-3" />
                <span>São Paulo, SP</span>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10 hover:text-white border border-white/20"
              >
                Portal do Cliente
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <div className="flex-shrink-0 flex items-center space-x-2">
              <div className="w-10 h-10 fc-orange rounded-lg flex items-center justify-center">
                <Truck className="w-6 h-6 text-white" />
              </div>
              <div className="text-fc-dark-gray">
                <div className="font-bold text-xl">FC Locações</div>
                <div className="text-xs text-fc-medium-gray">Caminhões Munck & Cestos Aéreos</div>
              </div>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className={`px-3 py-2 text-sm font-medium transition-colors duration-200 ${
                  currentPage === item.key
                    ? 'text-fc-orange border-b-2 border-fc-orange'
                    : 'text-fc-dark-gray hover:text-fc-orange'
                }`}
              >
                {item.name}
              </a>
            ))}
          </nav>

          {/* CTA Button */}
          <div className="hidden md:flex items-center space-x-4">
            <Button className="fc-orange hover:bg-orange-600 text-white">
              Solicitar Orçamento
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-fc-dark-gray"
            >
              {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden border-t border-gray-100">
          <div className="px-2 pt-2 pb-3 space-y-1 bg-white">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className={`block px-3 py-2 text-base font-medium transition-colors duration-200 ${
                  currentPage === item.key
                    ? 'text-fc-orange bg-orange-50'
                    : 'text-fc-dark-gray hover:text-fc-orange hover:bg-gray-50'
                }`}
                onClick={() => setIsMenuOpen(false)}
              >
                {item.name}
              </a>
            ))}
            <div className="px-3 py-2">
              <Button className="w-full fc-orange hover:bg-orange-600 text-white">
                Solicitar Orçamento
              </Button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}